Apply patch and enter your registration name
Maybe you will need restart Windows for fully working